#!/bin/bash
export SYSTEMD_COLORS=1 
echo ""
echo ""
echo "Disk space Utilization"
echo " Connecting..."
echo " Please wait"
ansible s89 -a "df -h"  -i ./hosts
echo ""
echo ""
echo ""
echo "Checking Memory"
echo " Please wait"
ansible s89 -a "free -h"  -i ./hosts
echo ""
echo ""
echo ""
echo "Done"
#ansible s89 -a "apt list -upgradable"  -i ./hosts
