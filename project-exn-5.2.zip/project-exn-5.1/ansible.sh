#!/bin/bash

echo "<html>"

echo "<body style='background-color:black;'>"
echo "<p style='color:#4AF626; font-family:Consolas; font-size:120%;'>"
echo "Runing apt update && apt list --upgradable"
ansible-playbook -i ./hosts ./playbooks/apt-check.yaml -e "ansible_become_password=Dam@#123"

echo "Done</p>"