import os
print(os.path.join(os.path.dirname(__file__)))
print(os.path.join(__file__).parent)