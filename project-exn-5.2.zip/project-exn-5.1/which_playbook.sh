#!/bin/bash

which ansible-playbook
