#!/bin/bash


echo $1

ansible  -i ./hosts linux_hosts -m listen_ports_facts
ansible  -i ./hosts "$1" -m "$2" 

echo "done"