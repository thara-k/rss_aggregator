#!/bin/bash
source exnEnv/bin/activate

nohup python manage.py runserver amugflx001.virtusa.com:8002 &


tail -100f nohup.out
