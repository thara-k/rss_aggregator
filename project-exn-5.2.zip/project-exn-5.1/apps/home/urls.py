# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from django.urls import path, re_path
from django.conf.urls import url
from apps.home import views
from django.conf import settings
from django.conf.urls.static import static
from django.urls import include, path

urlpatterns = [

    # The home page
    path('', views.index, name='home'),

    # Matches any html file
    # re_path(r'^.*\.*', views.pages, name='pages'),
    re_path(r'\.html$', views.pages, name='pages'),
    
    # path('inventorys', views.InventoryList.as_view(), name='inventorys'),
    path('inventory/view/<int:pk>', views.InventoryView.as_view(), name='inventory_view'),
    path('inventory/new', views.InventoryCreate.as_view(), name='inventory_new'),
    path('inventory/edit/<int:pk>', views.InventoryUpdate.as_view(), name='inventory_edit'),
    path('inventory/delete/<int:pk>', views.InventoryDelete.as_view(), name='inventory_delete'),

    path('groups', views.GroupList.as_view(), name='groups'),
    path('group/view/<int:pk>', views.GroupView.as_view(), name='group_view'),
    path('group/new', views.GroupCreate.as_view(), name='group_new'),
    path('group/edit/<int:pk>', views.GroupUpdate.as_view(), name='group_edit'),
    path('group/delete/<int:pk>', views.GroupDelete.as_view(), name='group_delete'),

    path('solutions', views.SolutionList.as_view(), name='solutions'),
    path('solution/view/<int:pk>', views.SolutionView.as_view(), name='solution_view'),
    path('solution/new', views.SolutionCreate.as_view(), name='solution_new'),
    path('solution/edit/<int:pk>', views.SolutionUpdate.as_view(), name='solution_edit'),
    path('solution/delete/<int:pk>', views.SolutionDelete.as_view(), name='solution_delete'),


    path('hostlist', views.HostList.as_view(), name='host_list'),
    path('hostslist', views.HostsList.as_view(), name='hosts_list'),
    path('host/view/<int:pk>', views.HostView.as_view(), name='host_view'),
    path('host/new', views.HostCreate.as_view(), name='host_new'),
    path('host/edit/<int:pk>', views.HostUpdate.as_view(), name='host_edit'),
    path('host/delete/<int:pk>', views.HostDelete.as_view(), name='host_delete'),

    path('playbook/view/<int:pk>', views.PlaybookView.as_view(), name='playbook_view'),
    path('playbook/new', views.PlaybookCreate.as_view(), name='playbook_new'),
    path('playbook/edit/<int:pk>', views.PlaybookUpdate.as_view(), name='playbook_edit'),
    path('playbook/delete/<int:pk>', views.PlaybookDelete.as_view(), name='playbook_delete'),
    # path('playbook/upload', views.playbook_upload, name='playbook_upload'),
    path('playbook/run', views.playbook_run, name='playbook_run'),
    

    # url(r'playbook_run$', views.playbook_run, name='playbook_run'),
    
    # url(r'^fileupload$', views.fileupload, name='fileupload'),
    # url(r'^playbooks$', views.playbook_upload, name='playbooks'),
    url(r'^playbooks$', views.playbooks, name='playbooks'),
    # url(r'^playbook_content$', views.playbook_content, name='playbook_content'),
    url(r'^inventorys$', views.inventory_upload, name='inventorys'),
    # url(r'^test/$', views.read_file, name='test'),
    # url(r'^uploads/form/$', views.model_form_upload, name='model_form_upload'),
    path("playbook/<int:pk>/", views.playbook_modal_view, name="playbook-modal"),
    # url(r'^popup/$', views.popup),

    path('vfmain/', views.vfmain, name='vfmain'),
    path('vulnerabilitys', views.VulnerabilityList.as_view(), name='vulnerabilitys'),
    path('vulnerability/view/<int:pk>', views.VulnerabilityView.as_view(), name='vulnerability_view'),
    path('vulnerability_delete_all', views.Vulnerability_delete_all, name='vulnerability_delete_all'),
    path('getvulnerabilities', views.VulnerabilityReport.as_view(), name='getvulnerabilities'),
    path('gethosts', views.HostReport.as_view(), name='gethosts'),

    path('upload_vuln', views.UploadVuln, name='upload_vuln'),
    path('upload_hosts', views.UploadHosts, name='upload_hosts'),
    path('run_playbook', views.RunPlaybook, name='run_playbook'),
    path('run_playbook2', views.RunPlaybook2, name='run_playbook2'),
    
    path('read/vulnerability/<int:pk>', views.VulnerabilityReadView.as_view(), name='read-vulnerability'),
    # path('read/<int:pk>', views.PlaybookReadView.as_view(), name='read-playbook'),
    #path('readplaybook/<int:pk>', views.PlaybookReadView, name='read-playbook'),
    url(r'^readplaybook$', views.readplaybook, name='playbook_content'),
    path('delete/<int:pk>', views.PlaybookDeleteView.as_view(), name='delete-playbook'),
    path('run-ansible', views.run_ansible, name='run-ansible'),
    path('which_ansible_playbook', views.which_ansible_playbook, name='which_ansible_playbook'),
    
    path('run-ansible-playbook', views.run_ansible_playbook, name='run-ansible-playbook'),
    url(r'^stream$', views.test_stream, name='test_stream'),
    path('newsfeed', views.newsfeed, name='newsfeed'),

    path('Starter', views.Starter, name='Starter'),

    path('hostvulnerability/edit/<int:pk>', views.HostVulnerabilityUpdate.as_view(), name='hostvulnerability_edit'),
    path('hostvulnerabilitystatusupdate/<int:pk>/edit/', views.hostvulnerabilitystatusupdate,name='hostvulnerabilitystatusupdate'),
    path('hostvulnerabilitys', views.HostVulnerabilityList.as_view(), name='hostvulnerabilitys'),
    path('playbooks_list/', views.playbooks_list, name='playbooks_list'),
    path('inventorylist/', views.inventorylist, name='inventorylist'),
    path('solutionselectview', views.SolutionSelectView, name='solutionselectview'),


]+ static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

# if settings.DEBUG:
    # urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

if settings.DEBUG:
    import debug_toolbar
    urlpatterns += [
        url(r'^__debug__/', include(debug_toolbar.urls)),
    ]
