# from django import forms
# from .models import Playbook

# class PlaybookForm(forms.ModelForm):
#     class Meta:
#         model = Playbook
#         fields = ( 'filepath', )

from django import forms
from django.forms import ModelForm


from .models import Playbook, Vulnerability, Host, HostVulnerability
from bootstrap_modal_forms.forms import BSModalModelForm, BSModalForm
from django.db.models.fields import GenericIPAddressField as IPAddressField


from bootstrap_modal_forms.generic import (
  BSModalCreateView,
  BSModalUpdateView,
  BSModalReadView,
  BSModalDeleteView
)


# class PlaybookModelForm(BSModalModelForm):
#     class Meta:
#         model = Playbook

class VulnerabilityModelForm(BSModalModelForm):
    class Meta:
        model = Vulnerability
        exclude = ['Category']


class HostVulnerabilityModelForm(ModelForm):
    class Meta:
        model = HostVulnerability
        fields = '__all__'

class HostModelForm(BSModalModelForm):
    password = forms.CharField(max_length=20, widget=forms.PasswordInput)
    # password = forms.CharField(widget=forms.PasswordInput())
    # password_confirm = forms.CharField(widget=forms.PasswordInput())
    class Meta:
        model = Host
        fields = [ 'DNS','NetBIOS','IP','owner','operatingsystem','Servertype','loginuser','password']
#        exclude = ['owner']
# # Read

class PlaybookForm(BSModalModelForm):
    class Meta:
        model = Playbook
        fields = ('id', 'filepath' )

class PlaybookChoiceField(forms.Form):
    playbooks = forms.ModelChoiceField
    queryset=Playbook.objects.all()
    
    
