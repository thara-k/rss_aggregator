from django_tables2.utils import A
from django_tables2 import Column, Table
import django_tables2 as tables
import django_tables2 as columns
import itertools
from .models import Playbook,Vulnerability, Host


class HostTable(tables.Table):
    counter = tables.Column(verbose_name="#", empty_values=(), orderable=False)
    # host = tables.Column(linkify=True)
    # owner = tables.Column(accessor="host__owner", linkify=True)
    class Meta:
        model = Vulnerability
        fields = ( 'counter', 'DNS',  'IP', 'operatingsystem','owner','Servertype' )  #,  , 'Port' 'FirstDetected', 'LastDetected', 'TimesDetected', 'DateLastFixed',   'FirstReopened', 'LastReopened', 'TimesReopened', 'CVEID',   'VendorReference', 'BugtraqID', 'Threat', 'Impact', 'Solution',   'Exploitability', 'Results', 'PCIVuln', 'TicketState', 'Category')
        attrs = {"class": "order-table table table-condensed  table-hover"}
        #template_name = 'django_tables2/bootstrap4.html'
        #template_name = 'django_tables2/semantic.html'
        template_name = 'django_tables2/bootstrap.html'
        #template_name = 'django_tables2/table.html'
        attrs={'th': {'style':'text-align: center;'}, 'td': {'align': 'center'}}
        attrs={'style':'width:90%;'}

    def render_counter(self):
        self.row_counter = getattr(self, 'row_counter', itertools.count(self.page.start_index()))
        return next(self.row_counter)
    

class PlaybookTable(tables.Table):
    counter = tables.Column(verbose_name="#", empty_values=(), orderable=False)
    #More = tables.TemplateColumn('<a href="/sliitnfcapp/getmyplaybookregistration/?Playbook={{record.id}}">Registered Students Details <i class="fa fa-link"></i></button></a>')
    More = tables.TemplateColumn('<a href="/home/vfmain/?Playbook={{record.id}}" class="btn-sm btn-primary a-btn-slide-text"><span class="fa fa-link" aria-hidden="true"></span><span> View</span> </a>')
    filepath = tables.Column(verbose_name="Playbook File")
    
    #name = tables.Column( attrs={ "th": {"id": "name"}, "td": {"align": "left"} })
    
    Edit = tables.TemplateColumn('<a href="{% url "playbook_edit" record.id %}" class="btn-sm btn-info a-btn-slide-text"><span class="fa fa-edit" aria-hidden="true"></span><span> Edit</span> </a>')
    Delete = tables.TemplateColumn('<a href="{% url "playbook_delete" record.id %}" class="btn-sm btn-danger a-btn-slide-text"> <span class="fa fa-remove" aria-hidden="true"></span><span> Delete</span> </a>')
    class Meta:
        model = Playbook
        fields = ( 'filepath', )
        attrs = {"class": "order-table table table-condensed  table-hover"}
        #template_name = 'django_tables2/bootstrap4.html'
        template_name = 'django_tables2/semantic.html'
        #template_name = 'django_tables2/bootstrap.html'
        #template_name = 'django_tables2/table.html'
        attrs={'th': {'style':'text-align: center;'}, 'td': {'align': 'center'}}
        attrs={'style':'width:80%;'}

    def render_counter(self):
        self.row_counter = getattr(self, 'row_counter', itertools.count(self.page.start_index()))
        return next(self.row_counter)
    

class VulnerabilityTable(tables.Table):
    counter = tables.Column(verbose_name="#", empty_values=(), orderable=False)
    More = tables.TemplateColumn('<button type="button" class="read-vulnerability btn btn-sm btn-primary"  data-form-url="/read/vulnerability/{{record.id}}" >View </span></button>', empty_values=(),orderable=False)
    # More2 = tables.TemplateColumn('<button type="button" class="read-vulnerability btn btn-sm btn-primary"  data-form-url="vulnerability/view/{{record.id}}" >View2 </span></button>', empty_values=(),orderable=False)
    # More2 = tables.TemplateColumn('<a href="/hostvulnerabilitystatusupdate/{{record.id}}/edit/" class="btn-sm btn-primary a-btn-slide-text"><span class="fa fa-link" aria-hidden="true"></span><span> View</span> </a>')
    #filepath = tables.Column(verbose_name="Vulnerability Report")
    #details = <button type="button" class="read-vulnerability btn btn-sm btn-primary"  data-form-url="{% url 'read-vulnerability' vulnerability.pk %}">View </span></button>
    Severity = tables.Column( attrs={ "th": {"id": "name"}, "td": {"align": "center"} })
    linkify = ("host", "host__owner")

    #Edit = tables.TemplateColumn('<a href="{% url "playbook_edit" record.id %}" class="btn-sm btn-info a-btn-slide-text"><span class="fa fa-edit" aria-hidden="true"></span><span> Edit</span> </a>')
    #Delete = tables.TemplateColumn('<a href="{% url "playbook_delete" record.id %}" class="btn-sm btn-danger a-btn-slide-text"> <span class="fa fa-remove" aria-hidden="true"></span><span> Delete</span> </a>')
    class Meta:
        model = Vulnerability
        fields = ( 'counter', 'IP', 'DNS',  'Title','OS', 'QID',   'Type', 'Severity' ,'owner', 'VulnStatus' )  #,  , 'Port' 'FirstDetected', 'LastDetected', 'TimesDetected', 'DateLastFixed',   'FirstReopened', 'LastReopened', 'TimesReopened', 'CVEID',   'VendorReference', 'BugtraqID', 'Threat', 'Impact', 'Solution',   'Exploitability', 'Results', 'PCIVuln', 'TicketState', 'Category')
        attrs = {"class": "order-table table table-condensed  table-hover"}
        #template_name = 'django_tables2/bootstrap4.html'
        #template_name = 'django_tables2/semantic.html'
        template_name = 'django_tables2/bootstrap.html'
        #template_name = 'django_tables2/table.html'
        attrs={'th': {'style':'text-align: center;'}, 'td': {'align': 'center'}}
        attrs={'style':'width:90%;'}

    def render_counter(self):
        self.row_counter = getattr(self, 'row_counter', itertools.count(self.page.start_index()))
        return next(self.row_counter)
    
