# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""
from __future__ import unicode_literals
from django.db import models
from django.contrib.auth.models import User
from django.db.models.fields import GenericIPAddressField as IPAddressField
from django.db.models import signals
from django.dispatch import receiver  
from django.conf import settings
from django.db.models.signals import post_save

# Create your models here.
import os

def get_upload_path(instance, filepath):
    return os.path.join(
      "user_%d" % instance.owner.id, "car_%s" % instance.slug, filepath)


from django.db import models


# class Document(models.Model):
#     description = models.CharField(max_length=255, blank=True)
#     document = models.FileField(upload_to='documents/')
#     uploaded_at = models.DateTimeField(auto_now_add=True)


class Document(models.Model):
    description = models.CharField(max_length=255, blank=True)
    document = models.CharField(max_length=255, )
    uploaded_at = models.DateTimeField(auto_now_add=True)

class Inventory(models.Model):
  id = models.AutoField(primary_key=True)
  name = models.CharField(max_length=100)
  filepath = models.FileField(upload_to='media/inventory/')
  uploaded_at = models.DateTimeField(auto_now_add=True)
  def __str__(self):
    return self.name

class Group(models.Model):
  id = models.AutoField(primary_key=True)
  name = models.CharField(max_length=100)
  def __str__(self):
    return self.name

class Host(models.Model):
  SERVERTYPE = (
      (1, ('Non-Prod')),
      (2, ('PROD'))
  )

  OPERATINGSYSTEM = (
      (1 ,('Windows Server 2012 R2 Standard 64 bit Edition')),
      (2 ,('Windows Server 2016 Datacenter 64 bit Edition Version 1607')),
      (3 ,('Windows Server 2012 R2 Standard 64 bit Edition')),
      (4 ,('Windows 2012 R2/8.1')),
      (5 ,('Windows Server 2012 R2 Datacenter 64 bit Edition')),
      (6 ,('Windows 2016/2019/10')),
      (7 ,('Linux 2.x')),
      (8 ,('Windows Server 2016 Standard 64 bit Edition Version 1607')),
      (9 ,('CentOS Linux 7.9.2009')),
      (10 ,('Ubuntu Linux 18.04.5')),
      (11 ,('Ubuntu Linux 18.04.6')),
      (12 ,('Ubuntu Linux 20.04.6')),
      (13 ,('Windows Server 2019 Datacenter 64 bit Edition Version 1809 Build 17763')),
      (14  ,('Windows 10 Enterprise 64 bit Edition Version 2009')),
      (15,  ('Windows Server 2019 Standard 64 bit Edition Version 1809 Build 17763')),
      (16,('Ubuntu Linux 20.04.3'))
  )

  OWNERS = (
      (0 , ('TBD')),
      (1 , ('Pramod Chamka Sendanayake-Owner')),
      (2 , ('GTFQA Team-Used')),
      (3 , ('Pramod Chamka Sendanayake -Owner and GTO Team/shehani Edirisinghe')),
      (4 , ('Pramod Chamka Sendanayake/Dian Jayasooriya/Hasini -Owner and GTO Team')),
      (5 , ('Anusha Yapa and RPA Flex Team')),
      (6 , ('Pramod Chamka Sendanayake -Owner and GTO Team')),
      (7 , ('Pramod Chamka Sendanayake/Hasini -Owner and GTO Team ')),
      (8 , ('Pramod Chamka Sendanayake -Owner and Dian Jayasooriya')),
      (9 , ('Pramod Chamka Sendanayake -Owner and Sahan Perera')),
      (10  , ('Pramod Chamka Sendanayake -Owner ,Udeeptha Lokubalasooriya and Dilan Salinda ')),
      (11  , ('Pramod Chamka Sendanayake -Owner and Dasan Ikmal ')),
      (12  , ('Pramod Chamka Sendanayake -Owner and GTO Team/Dasan Lakmal ')),
      (13  , ('Pramod Chamka Sendanayake-Owner,  Tharaka Mahabage  and GTFDeployemt Team')),
      (14  , ('Pramod Chamka Sendanayake -Owner  and GTO Team/sathira ')),
      (15  , ('Tharaka Mahabage-Owner  and GTFDeployemt Team')),
      (16  , ('Achanai Wickramasinghe-Owner and GTF QA Team ')),
      (17  , ('Viknesh Subramaniyam -Owner and GTF Dev Team ')),
      (18  , ('Viknesh Subramaniyam -Owner')),
      (19  , ('Pubudu Dissanayake-Owner and Used by GTF Deployment Team ')),
      (20  , ('Kandasami Wasanthekumar -Owner ')),
      (21  , ('Tharindu Wathukara,Dilanka Tharindi and GTF Dev Team ')),
      (22  , ('Tharaka & Dian ')),
      (23  , ('GTF Team')),
      (24	, ('Achanai Wickramasinghe-Owner and GTF QA Team')),
      (25	, ('Pramod Chamka Sendanayake -Owner and GTO Team/Anusha yapa')),
      (26	, ('GTF Dev Team')),
      (27	, ('Dasan')),
      (28	, ('Sathira')),
      )
  id = models.AutoField(primary_key=True)
  DNS = models.CharField(max_length=100,null=True)
  NetBIOS = models.CharField(max_length=100,null=True)
  loginuser = models.CharField(max_length=100,null=True)
  password    = models.CharField(max_length=100,null=True)
  operatingsystem = models.PositiveSmallIntegerField(
      choices=OPERATINGSYSTEM,
      default=12,
   )
  IP = models.GenericIPAddressField()
  owner = models.PositiveSmallIntegerField(
      choices=OWNERS,
      default=1,
   )
  Servertype = models.PositiveSmallIntegerField(
      choices=SERVERTYPE,
      default=1,
   )
  host_vulnerabilities = models.ManyToManyField('Vulnerability', through='HostVulnerability', related_name='vulnerabilitys',null=True)
  Remarks = models.CharField(max_length=500)


  def __str__(self):
    return self.IP

class Playbook(models.Model):
  id = models.AutoField(primary_key=True)
  filepath = models.FileField(upload_to='.')
  uploaded_at = models.DateTimeField(auto_now_add=True)
 # filepath = models.FilePathField(path=settings.PLAYBOOK_PATH_FIELD_DIRECTORY)
  def __str__(self):
        return str(self.filepath)


def display_text_file(self):
    with open(self.text.path) as fp:
        return fp.read().replace('\n', '<br>')


class Vulnerability(models.Model):
    id =  models.AutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID') 
    IP = models.GenericIPAddressField()
    DNS	=	models.CharField(max_length=75,default='NA',blank=True)
    NetBIOS	=	models.CharField(max_length=50,default='NA',blank=True)
    TrackingMethod	=	models.CharField(max_length=5,default='NA',blank=True)
    OS	=	models.CharField(max_length=50,default='NA',blank=True)
    IPStatus	=	models.CharField(max_length=20,default='NA',blank=True)
    QID	=	models.CharField(max_length=10,default='NA',blank=True)
    Title	=	models.CharField(max_length=100,default='NA',blank=True)
    VulnStatus	=	models.CharField(max_length=20,default='NA',blank=True)
    Type	=	models.CharField(max_length=10,default='NA',blank=True)
    Severity	=	models.CharField(max_length=2,default='NA',blank=True)
    Port	=	models.CharField(max_length=5,default='NA',blank=True)
    Protocol = models.CharField(max_length=5,default='NA',blank=True)
    FQDN  = models.CharField(max_length=100,default='NA',blank=True)
    SSL  = models.CharField(max_length=100,default='NA',blank=True)
    FirstDetected	=	models.DateTimeField(auto_now_add=True,null=True, blank=True)
    LastDetected	=	models.DateTimeField(auto_now_add=True,null=True, blank=True)
    TimesDetected	=	models.IntegerField(default=0)
    DateLastFixed	=	models.DateTimeField(auto_now_add=True,null=True, blank=True)
    FirstReopened	=	models.DateTimeField(auto_now_add=True,null=True, blank=True)
    LastReopened	=	models.DateTimeField(auto_now_add=True,null=True, blank=True)
    TimesReopened	=	models.IntegerField()
    CVEID	=	models.CharField(max_length=25,default='NA',blank=True)
    VendorReference	=	models.CharField(max_length=100,default='NA',blank=True)
    BugtraqID	=	models.CharField(max_length=5,default='NA',blank=True)
    Threat	=	models.CharField(max_length=800,default='NA',blank=True)
    Impact	=	models.CharField(max_length=800,default='NA',blank=True)
    Solution	=	models.CharField(max_length=800,default='NA',blank=True)
    Exploitability	=	models.CharField(max_length=800,default='NA',blank=True)
    Results	=	models.CharField(max_length=800,default='NA',blank=True)
    PCIVuln	=	models.CharField(max_length=20,default='NA',blank=True)
    TicketState	=	models.CharField(max_length=10,default='NA',blank=True)
    Instance	=	models.CharField(max_length=10,default='NA',blank=True)
    Category	=	models.CharField(max_length=25,default='NA',blank=True)
    owner	=	models.CharField(max_length=100,default='NA',blank=True)
    
    #host_ipaddress = models.ForeignKey(Host,on_delete=models.DO_NOTHING, default=1)
    def __str__(self):
        return "%s %s" % (self.QID, self.Title)

HOSTVULNERABILITYSTATUS = (
      (1, ('Open')),
      (2, ('Closed')),
      (3, ('in-progess')),
      (4, ('False Positive')),
      (5, ('Fix Applied')),
      (6, ('Request Support')),
      (7, ('Errors when Applying fix')),
)
class HostVulnerability(models.Model):
  id = models.AutoField(primary_key=True)
  host = models.ForeignKey(Host ,on_delete=models.DO_NOTHING,db_constraint=False)
  vulnerability = models.ForeignKey(Vulnerability,on_delete=models.CASCADE,db_constraint=False)
  comment	=	models.CharField(max_length=500,default='NA',blank=True)
  status = models.PositiveSmallIntegerField(
      choices=HOSTVULNERABILITYSTATUS,
      default=1,
   )
  created_on = models.DateTimeField(auto_now_add=True,null=True, blank=True)


  def __str__(self):
    return "%s %s" % (self.Host, self.vulnerability)


class Solution(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=500,default='NA',blank=True)
    details = models.CharField(max_length=500,default='NA',blank=True)
    playbook = models.ForeignKey(Playbook,on_delete=models.DO_NOTHING)
    vulnerability = models.ForeignKey(Vulnerability,on_delete=models.CASCADE)

    def __str__(self):
        return self.name


class Qualys(models.Model):
    id = models.AutoField(primary_key=True)
    Title = models.CharField(max_length=500,default='NA',blank=True)
    QID = models.CharField(max_length=500,default='NA',blank=True)

@receiver(signals.post_save, sender=HostVulnerability) 
def create_hostvulnerability(sender, **kwargs):
    print("Save method is called")


@receiver(signals.post_save, sender=Vulnerability) 
def create_vulnerability(sender, **kwargs):
    print("Save method is called")


# #sender is the Model after which save method the signal is called
# @receiver(post_save, sender=HostVulnerability) 
# def signal_receiver(sender, instance, created, **kwargs):
#     # instance is the new GroupUsers
#     group = instance.group
#     user = instance.user
#     # loop over Group_colors and create User_Colors
#     for color in group.gc_color.all():
#         Users_Colors.objects.create(user=user, color.color)