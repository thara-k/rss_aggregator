# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""
from django.http import HttpResponse, HttpResponseRedirect, StreamingHttpResponse
from django.views.generic.base import TemplateView
from django import template
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, HttpResponseRedirect
from django.template import loader
from django.urls import reverse
from django.shortcuts import render, redirect
from django.db.models.fields import GenericIPAddressField as IPAddressField



from django_tables2 import SingleTableMixin
from django_filters.views import FilterView
from django.views.generic import ListView, DetailView, FormView
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.core.files.storage import FileSystemStorage
import datetime
from django.views.decorators.csrf import csrf_exempt,csrf_protect #Add this
from .models import Inventory, Group, Host, Playbook, Vulnerability, Solution, HostVulnerability
from django.conf import settings #or from my_project import settings
from .tables import VulnerabilityTable, HostTable
from .filters import VulnerabilityFilter, HostFilter
#from .serializers import PlaybookSerializer
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import get_object_or_404
from django.http import HttpResponse
from datetime import datetime as dt
from django.http import JsonResponse
from django.template.loader import render_to_string
from django.contrib.messages.views import SuccessMessageMixin
from django.urls import reverse_lazy
from django.views import generic

import pandas as pd
import numpy as np
import bs4
import re
import datetime
from django.contrib import messages
import os
from bootstrap_modal_forms.generic import (
    BSModalReadView,BSModalDeleteView
    
)
from .ansible import exec_ansible_apt_updater, example, exec_ansible_playbook_runner,exec_which_ansible_playbook
from .forms import PlaybookChoiceField, HostVulnerabilityModelForm
# from .forms import Vul
@login_required(login_url="/login/")
# def index(request):
#     context = {'segment': 'index'}

#     html_template = loader.get_template('home/index.html')
#     return HttpResponse(html_template.render(context, request))

def index(request):
      return HttpResponseRedirect('/getvulnerabilities')

@login_required(login_url="/login/")
def pages(request):
    context = {}
    # All resource paths end in .html.
    # Pick out the html file name from the url. And load that template.
    try:

        load_template = request.path.split('/')[-1]

        if load_template == 'admin':
            return HttpResponseRedirect(reverse('admin:index'))
        context['segment'] = load_template

        html_template = loader.get_template('home/' + load_template)
        return HttpResponse(html_template.render(context, request))

    except template.TemplateDoesNotExist:

        html_template = loader.get_template('home/page-404.html')
        return HttpResponse(html_template.render(context, request))

    except:
        html_template = loader.get_template('home/page-500.html')
        return HttpResponse(html_template.render(context, request))


############ Inventory #############
class InventoryList(ListView):
    model = Inventory	
	
class InventoryView(DetailView):
    model = Inventory

class InventoryCreate(CreateView):
    model = Inventory
    fields = [ 'name','filepath']
    success_url = reverse_lazy('inventorys')

class InventoryUpdate(UpdateView):
    model = Inventory
    fields = [ 'name','filepath']
    success_url = reverse_lazy('inventorys')

class InventoryDelete(DeleteView):
    model = Inventory
    success_url = reverse_lazy('inventorys')


############ Host #############
class HostList(ListView):
    model = Host	
	
class HostsList(ListView):
    model = Host	
	

class HostView(DetailView):
    model = Host

class HostCreate(CreateView):
    model = Host
    fields = [ 'DNS','NetBIOS','IP','owner','operatingsystem','Servertype','loginuser','password']
    success_url = reverse_lazy('host_list')

class HostUpdate(UpdateView):
    model = Host
    fields = [ 'DNS','NetBIOS','IP','owner','operatingsystem','Servertype','loginuser','password']
    success_url = reverse_lazy('host_list')

class HostDelete(DeleteView):
    model = Host
    success_url = reverse_lazy('host_list')



############ Group #############
class GroupList(ListView):
    model = Group   
    
class GroupView(DetailView):
    model = Group

class GroupCreate(CreateView):
    model = Group
    fields = [ 'name']
    success_url = reverse_lazy('groups')

class GroupUpdate(UpdateView):
    model = Group
    fields = [ 'name']
    success_url = reverse_lazy('groups')

class GroupDelete(DeleteView):
    model = Group
    success_url = reverse_lazy('groups')


############ Solution #############
class SolutionList(ListView):
    model = Solution   
    
class SolutionView(DetailView):
    model = Solution

class SolutionCreate(CreateView):
    model = Solution
    fields = [ 'id','name','details','vulnerability','playbook']
    success_url = reverse_lazy('solutions')

class SolutionUpdate(UpdateView):
    model = Solution
    fields = [ 'id','name','details','vulnerability','playbook']
    success_url = reverse_lazy('solutions')

class SolutionDelete(DeleteView):
    model = Solution
    success_url = reverse_lazy('solutions')



def SolutionSelectView(request):
    playbook_list = PlaybookChoiceField()
    # inventory_list =  Inventory.objects.all()

    context = {
        'playbook_list': playbook_list,
        # 'inventory_list': inventory_list, 

    }
    return render(request,'home/SolutionSelectView.html', context)

############ Playbook #############
class PlaybookList(ListView):
    model = Playbook   
    
class PlaybookView(DetailView):
    model = Playbook

class PlaybookCreate(CreateView):
    model = Playbook
    fields = [ 'filepath','uploaded_at']
    success_url = reverse_lazy('playbooks')

class PlaybookUpdate(UpdateView):
    model = Playbook
    fields = [ 'filepath','uploaded_at']
    success_url = reverse_lazy('playbooks')

class PlaybookDelete(DeleteView):
    model = Playbook
    success_url = reverse_lazy('playbooks')

########### Vulnerability #############
class VulnerabilityList(ListView):
    model = Vulnerability

class VulnerabilityView(DetailView):
    model = Vulnerability

class VulnerabilityCreate(CreateView):
    model = Vulnerability
    fields=['IP', 'DNS', 'NetBIOS', 'TrackingMethod', 'OS', 'IPStatus', 'QID',   'Title', 'VulnStatus', 'Type', 'Severity', 'Port', 'Protocol',   'FirstDetected', 'LastDetected', 'TimesDetected', 'DateLastFixed',   'FirstReopened', 'LastReopened', 'TimesReopened', 'CVEID',   'VendorReference', 'BugtraqID', 'Threat', 'Impact', 'Solution',   'Exploitability', 'Results', 'PCIVuln', 'TicketState', 'Category']  
    success_url = reverse_lazy('vulnerabilitys')

class VulnerabilityUpdate(UpdateView):
    model = Vulnerability
    fields=['IP', 'DNS', 'NetBIOS', 'TrackingMethod', 'OS', 'IPStatus', 'QID',   'Title', 'VulnStatus', 'Type', 'Severity', 'Port', 'Protocol',   'FirstDetected', 'LastDetected', 'TimesDetected', 'DateLastFixed',   'FirstReopened', 'LastReopened', 'TimesReopened', 'CVEID',   'VendorReference', 'BugtraqID', 'Threat', 'Impact', 'Solution',   'Exploitability', 'Results', 'PCIVuln', 'TicketState', 'Category']
    success_url = reverse_lazy('vulnerabilitys')

class VulnerabilityDelete(DeleteView):
    model = Vulnerability
    success_url = reverse_lazy('vulnerabilitys')

def Vulnerability_delete_all(self):
  Vulnerability.objects.all().delete()
  return redirect('vulnerabilitys')
# def playbook_upload(request):
#     if request.method == 'POST' and request.FILES['myfile']:
#         myfile = request.FILES['myfile']
#         fs = FileSystemStorage()
#         playbook = Playbook(
#             filepath=myfile.name,
#             uploaded_at=datetime.datetime.now(), )
#         playbook.save()
#         messages.success(request, 'Playbook Added successfully!')
#         filename = fs.save(myfile.name, myfile)
#         uploaded_file_url = fs.url(filename)
#         return redirect('playbooks')
#     else:
#         playbooks = Playbook.objects.order_by('-uploaded_at')[:3]
#         context = {'playbooks': playbooks}
#     return render(request, 'home/playbooks.html', context)



from django.shortcuts import render, redirect
from django.conf import settings
from django.core.files.storage import FileSystemStorage


# def fileupload(request):
#     if request.method == 'POST' and request.FILES['myfile']:
#         myfile = request.FILES['myfile']
#         fs = FileSystemStorage()
#         document = Document(
#             description=request.POST['description'],
#             document=myfile.name,
#             uploaded_at=datetime.datetime.now(), )
#         document.save()
#         messages.success(request, 'Member was created successfully!')
#         filename = fs.save(myfile.name, myfile)
#         uploaded_file_url = fs.url(filename)
#         return redirect('fileupload')
#     else:
#         documents = Document.objects.order_by('-uploaded_at')[:3]
#         context = {'documents': documents}
#     return render(request, 'home/fileupload.html', context)

@csrf_exempt
def playbooks(request):
    print (settings.MEDIA_ROOT)
    
    if request.method == 'POST' and 'ViewButton' in request.POST:
        print(request.POST['ViewButton'])    
        with open (settings.MEDIA_ROOT+"/"+request.POST['ViewButton']) as fl:
            filebody = fl.read()
        fl.close
        return render(request, 'home/playbooks.html',{'filebody':filebody,'path':request.POST['ViewButton']})
    
    elif request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        playbook = Playbook(
            filepath=myfile.name,
            uploaded_at=datetime.datetime.now(), )
        playbook.save()
        messages.success(request, 'Playbook Added successfully!')
        filename = fs.save(myfile.name, myfile)
        # uploaded_file_url = fs.url(filename)
        return redirect('playbooks')
    else:
        playbooks = Playbook.objects.order_by('-uploaded_at')[:20]
        context = {'playbooks': playbooks}
        return render(request, 'home/playbooks.html', context)

# def playbooks1(request):
#     if request.method == 'POST' and request.FILES['myfile1']:
#         myfile1 = request.FILES['myfile1']
#         fs = FileSystemStorage()
#         playbook = Playbook(
#             filepath=myfile1.name,
#             uploaded_at=datetime.datetime.now(), )
#         playbook.save()
#         messages.success(request, 'Playbook Added successfully!')
#         filename = fs.save(myfile1.name, myfile1)
#         uploaded_file_url = fs.url(filename)
#         return redirect('playbooks1')

#     elif request.method == 'POST' and 'EditButton' in request.POST:
#         with open (request.POST['EditButton']) as fl:
#             filebody = fl.read()
#         fl.close
#         return render(request, 'home/edit_playbook.html',{'filebody':filebody,'filepath':request.POST['EditButton']})

#     else: 
#         playbooks = Playbook.objects.order_by('-uploaded_at')[:20]
#         context = {'playbooks1': playbooks}
#     return render(request, 'home/playbooks1.html', context)


    


def inventory_upload(request):
    if request.method == 'POST' and request.FILES['myfile']:
        myfile = request.FILES['myfile']
        fs = FileSystemStorage()
        inventory = Inventory(
            filepath=myfile.name,
            uploaded_at=datetime.datetime.now(), )
        inventory.save()
        messages.success(request, 'Inventory Added successfully!')
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        return redirect('inventorys')
    else:
        inventorys = Inventory.objects.order_by('-uploaded_at')[:10]
        context = {'inventorys': inventorys}
    return render(request, 'home/inventorys.html', context)


# View for the modal
@login_required
def playbook_modal_view(request, pk):
    playbook = get_object_or_404(playbooks, pk=pk)
    short_description = playbook.short_description
    return render(request, "modal01.html", locals())




from subprocess import Popen, PIPE
from django.shortcuts import render

from django.shortcuts import render,HttpResponse
import subprocess

def RunPlaybook(request):

    
    if request.method == 'POST' and 'ViewButton' in request.POST:
        print(request.POST['ViewButton'])    
        with open (settings.MEDIA_ROOT+"/"+request.POST['ViewButton']) as fl:
            filebody = fl.read()
        fl.close
        return render(request, 'home/run_playbook.html',{'filebody':filebody,'path':request.POST['ViewButton']})
    elif request.method == 'POST' and request.FILES['myfile2']:
        myfile2 = request.FILES['myfile2']
        fs = FileSystemStorage()
        playbook = Playbook(
            filepath=myfile2.name,
            uploaded_at=datetime.datetime.now(), )
        playbook.save()
        messages.success(request, 'Playbook Added successfully!')
        filename = fs.save(myfile2.name, myfile2)
        uploaded_file_url = fs.url(filename)
        return redirect('playbooks')
    else:
        playbooks = Playbook.objects.order_by('-uploaded_at')[:20]
        # inventorys = Inventory.objects.all()
        context = {'playbooks': playbooks}
        return render(request, 'home/run_playbook.html', context)

  


class vfmain(TemplateView):
    """
    Because our needs are so simple, all we have to do is
    assign one value; template_name. The home.html file will be created
    in the next lesson.
    """
    template_name = 'home/vfmain.html'

def UploadVuln(request):
    if 'GET' == request.method:
        # csv_list = Vulnerability.objects.all()
        # paginator = Paginator(csv_list, 7)
        # page = request.GET.get('page')
        # try:
        #     vulndf = paginator.page(page)
        # except PageNotAnInteger:
        #     vulndf = paginator.page(1)
        # except EmptyPage:
        #     vulndf = paginator.page(paginator.num_pages)
        # return render(request, 'upload_vuln.html', {'vulndf': vulndf})
        vulndf = Vulnerability.objects.all()
        context = {'vulndf': vulndf}
        return render(request, 'upload_vuln', context)

    elif request.method == 'POST' and request.FILES['csv_file']:
        try:
            csv_file = request.FILES["csv_file"]
            fs = FileSystemStorage()
            csv_file = fs.save(csv_file.name, csv_file)
            messages.success(request, 'CSV File Added successfully!')
            print(csv_file)
            csv_file_new = "/Users/tkmahabage/projectV0/projectV0_v1.1/project-exn-1.0/core/media"+"/"+csv_file
            os.rename(csv_file_new,'temp_work/temp_vulndf.csv')

            # csv_file = request.FILES["csv_file"]

            if len(csv_file) == 0:
                messages.error(request, 'Empty File')
                return render(request, '/home/upload_vuln.html')

            # if not csv_file.name.endswith('.csv'):
            #     messages.error(request, 'File is not CSV type')
            #     return render(request, 'upload_vuln.html')

            # if csv_file.multiple_chunks():
            #     messages.error(request, 'Uploaded file is too big (%.2f MB).' % (csv_file.size / (1000 * 1000),))
            #     return render(request, '/home/upload_vuln.html')
            
            #file_data = csv_file.read().decode("utf-8")
            with open("temp_work/temp_vulndf.csv", "r") as f:
                lines = f.readlines()
            with open("temp_work/temp_vulndf_.csv", "w") as f:
                for line in lines:
                    replaced_text = line.replace('host scanned, found vuln', 'host scanned found vuln')
                    f.write(replaced_text)
            csv_file="temp_work/temp_vulndf_.csv"
            #file_data = csv_file.read().decode("utf-8-sig")
            vulndf = pd.read_csv(csv_file) #, skiprows=1)
            # print(vulndf.head())
            df1 = pd.read_csv('temp_work/hosts.csv')
            vulndf = pd.merge(df1, 
                      vulndf, 
                      on ='IP', 
                      how ='inner')
            vulndf

            vulndf.to_csv('temp_work/temp_vulndf.csv', index=False)
            
            vulndf['Times Reopened'] = vulndf['Times Reopened'].fillna(0)
            vulndf.fillna('NA', inplace=True)
            # def encode_string_with_links(unencoded_string):
            #     return URL_REGEX.sub(r'<a href="\1">\1</a>', unencoded_string)

            # with open('temp_work/temp_vulndf.csv') as fh: 
            #     for line in fh: 
            #         #urls = re.findall('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+',line)
            #         urls = re.sub('http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\(\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+',r'<a href="\1">\1</a>', line)
            #         print("Urls: ",urls)
            # lookup='Last Reopened'


            # vulndf = pd.read_csv('temp_work/temp_vulndf_.csv',sep=',',skiprows=5)

            #print(vulndf.info)
            # print(vulndf['First Detected'])
            # vulndf['First Detected'] = pd.to_datetime(vulndf['First Detected'] ,errors = 'coerce',format = "%m/%d/%Y %H:%M:%S").dt.strftime("%Y-%m-%d %H:%M:%S")
            # vulndf['First Reopened'] = pd.to_datetime(vulndf['First Reopened'] ,errors = 'coerce',format = "%m/%d/%Y %H:%M:%S").dt.strftime("%Y-%m-%d %H:%M:%S")
            # vulndf['Last Detected'] = pd.to_datetime(vulndf['Last Detected'] ,errors = 'coerce',format = "%m/%d/%Y %H:%M:%S").dt.strftime("%Y-%m-%d %H:%M:%S")
            # vulndf['Last Reopened'] = pd.to_datetime(vulndf['Last Reopened'] ,errors = 'coerce',format = "%m/%d/%Y %H:%M:%S").dt.strftime("%Y-%m-%d %H:%M:%S")
            # vulndf['Date Last Fixed'] = pd.to_datetime(vulndf['Date Last Fixed'] ,errors = 'coerce',format = "%m/%d/%Y %H:%M:%S").dt.strftime("%Y-%m-%d %H:%M:%S")
            Vulnerability.objects.all().delete()


            
            
   

            
            # dt = str(datetime.datetime.now())
            dt = datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
            newname = 'temp_work/temp_vulndf_'+dt+'.csv'

            os.remove( 'temp_work/temp_vulndf.csv')  
            newname = 'temp_work/vulnerability_report_'+dt+'.csv'
            os.rename('temp_work/temp_vulndf_.csv', newname)

            

            # vulndf['Times Reopened'] = vulndf['Times Reopened'].fillna(0)
            # for index, row in vulndf.iterrows():
                # print(row, '\n')
            try:
                for index, row in vulndf.iterrows():
                    model = Vulnerability()
                    #print(row())
                    model.IP=row['IP']
                    model.DNS=row['DNS']
                    model.NetBIOS=row['NetBIOS']
                    model.TrackingMethod=row['Tracking Method']
                    model.OS=row['OS']
                    model.IPStatus=row['IP Status']
                    model.QID=row['QID']
                    model.Title=row['Title']
                    model.VulnStatus=row['Vuln Status']
                    model.Type=row['Type']
                    model.Severity=row['Severity']
                    model.Port=row['Port']
                    model.Protocol=row['Protocol']
                    model.FQDN=row['FQDN']
                    model.SSL=row['SSL']
                    model.FirstDetected =  row['First Detected']
                    model.LastDetected = row['Last Detected']
                    model.DateLastFixed =  row['Date Last Fixed']
                    model.FirstReopened = row['First Reopened']
                    model.LastReopened = row['Last Reopened']
                    model.TimesDetected=row.get(['Times Detected'],1)
                    model.TimesReopened=row['Times Reopened']
                    model.CVEID=row['CVE ID']
                    model.VendorReference=row['Vendor Reference']
                    model.BugtraqID=row['Bugtraq ID']
                    model.Threat=row['Threat']
                    model.Impact=row['Impact']
                    model.Solution=row['Solution']
                    model.Exploitability=row['Exploitability']
                    model.Results=row['Results']
                    model.PCIVuln=row['PCI Vuln']
                    model.TicketState=row['Ticket State']
                    model.Instance=row['Instance']
                    model.Category=row['Category']
                    model.save(force_insert=True)
                    
                    # model2 = HostVulnerability()
                    # model2.host = Host.objects.get(id=model.IP) #row['IP'] Host.objects.get(id=model.id)
                    # model2.vulnerability = Vulnerability.objects.get(id=model.id) # model.id # row['IP']
                    # model2.comment = 'New'
                    # model2.status = 1
                    # model2.save(force_insert=True)
            except KeyError as e:
                print (e)
            # print (vulndf.head)

            messages.success(request, "Successfully Uploaded CSV File")
            return redirect('getvulnerabilities')

        except Exception as e:
            messages.error(request, "Unable to upload file. " + e)
            return redirect('/home/upload_vuln.html')

     

#=============================================================================================================================================

def UploadHosts(request):
    if 'GET' == request.method:
        hostsdf = Host.objects.all()
        context = {'hostsdf': hostsdf}
        return render(request, 'upload_hosts', context)

    elif request.method == 'POST' and request.FILES['csv_file']:
        try:
            csv_file = request.FILES["csv_file"]
            fs = FileSystemStorage()
            csv_file = fs.save(csv_file.name, csv_file)
            messages.success(request, 'CSV File Added successfully!')
            print(csv_file)
            csv_file_new = "/Users/tkmahabage/projectV0/projectV0_v1.1/project-exn-1.0/core/media"+"/"+csv_file
            os.rename(csv_file_new,'temp_work/temp_hostsdf.csv')
            Host.objects.all().delete()

            # csv_file = request.FILES["csv_file"]

            if len(csv_file) == 0:
                messages.error(request, 'Empty File')
                return render(request, '/home/upload_hosts.html')

            # if not csv_file.name.endswith('.csv'):
            #     messages.error(request, 'File is not CSV type')
            #     return render(request, 'upload_hosts.html')

            # if csv_file.multiple_chunks():
            #     messages.error(request, 'Uploaded file is too big (%.2f MB).' % (csv_file.size / (1000 * 1000),))
            #     return render(request, '/home/upload_hosts.html')
            
            #file_data = csv_file.read().decode("utf-8")
            with open("temp_work/temp_hostsdf.csv", "r") as f:
                lines = f.readlines()
            with open("temp_work/temp_hostsdf_.csv", "w") as f:
                for line in lines:
                    replaced_text = line.replace('host scanned, found vuln', 'host scanned found vuln')
                    f.write(replaced_text)
            csv_file="temp_work/temp_hostsdf_.csv"
            #file_data = csv_file.read().decode("utf-8-sig")
            hostsdf = pd.read_csv(csv_file) #, skiprows=1)
            print(hostsdf.head())
            hostsdf.to_csv('temp_work/temp_hostsdf.csv', index=False)
            hostsdf.fillna('NA', inplace=True)
            
            # Host.objects.all().delete()
            # dt = str(datetime.datetime.now())
            dt = datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
            newname = 'temp_work/temp_hostsdf_'+dt+'.csv'

            os.remove( 'temp_work/temp_hostsdf.csv')  
            newname = 'temp_work/Host_report_'+dt+'.csv'
            os.rename('temp_work/temp_hostsdf_.csv', newname)


            # hostsdf['Times Reopened'] = hostsdf['Times Reopened'].fillna(0)
            # for index, row in hostsdf.iterrows():
                # print(row, '\n')
            try:
                for index, row in hostsdf.iterrows():
                    model = Host()
                    # print(row())
                    model.IP=row['IP']
                    model.DNS=row['DNS']
                    model.NetBIOS=row['NetBIOS']
                    model.operatingsystem=row['OS']
                    model.owner=row['owner']
                    model.Servertype=row['prod_non_prod']
                    model.loginuser=row['loginuser']
                    model.password=row['password']
                    model.save(force_insert=True)
                    
                    # model2 = HostHost()
                    # model2.host = Host.objects.get(id=model.IP) #row['IP'] Host.objects.get(id=model.id)
                    # model2.Host = Host.objects.get(id=model.id) # model.id # row['IP']
                    # model2.comment = 'New'
                    # model2.status = 1
                    # model2.save(force_insert=True)
            except KeyError as e:
                print (e)
            # print (hostsdf.head)

            messages.success(request, "Successfully Uploaded servers CSV File")
            return redirect('host_list')

        except Exception as e:
            messages.error(request, "Unable to upload file. " + e)
            return redirect('/home/upload_hosts.html')

#=============================================================================================================================================

def playbooks_list(request):
    results=Playbook.objects.all
    print(results)
    return render(request, "solution_list.html",{"show_playbooks_list":results})


#=============================================================================================================================================

def inventorylist(request):
    inv_results=Inventory.objects.all
    return render(request, "solution_list.html",{"showinventorylist":inv_results})
#=============================================================================================================================================
def RunPlaybook2(request):
    if request.method == 'POST' in request.POST:
        print(request.POST) 
    # if request.method == 'POST':
    #        print(request.POST)
    process = subprocess.Popen("sh /Users/tkmahabage/projectV0/playbooks/runcmd.sh", cwd='/Users/tkmahabage/ansible/web-ui/dashboard_01/django-subprocess/', stdin=subprocess.PIPE,shell=True,stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    out, err = process.communicate() #[0].decode("utf-8")

    list,ii={},0
    data=out.decode('utf-8').split('\n')
    for i in data:
        if(i!=""):
            list[ii]=i.split(':')
            ii += 1
    list.pop(0, None)
    return render(request,"home/run_playbook2.html",context={"list":list})



def playbook_run(cmd):
    if cmd.method == 'POST' and 'Run' in cmd.POST:
        print(cmd.POST['cmd'])   
    # process = subprocess.Popen("ansible-playbook", cwd='/Users/tkmahabage/ansible/web-ui/dashboard_01/django-subprocess/', stdin=subprocess.PIPE,shell=True,stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    # out, err = process.communicate() #[0].decode("utf-8")
    

    # list,ii={},0
    # data=out.decode('utf-8').split('\n')
    # for i in data:
    #     if(i!=""):
    #         list[ii]=i.split(' ')
    #         ii += 1
    # list.pop(0, None)
        return render(cmd,"home/playbook_run.html",context={"cmd":cmd})


def run_ansible(request):
    return StreamingHttpResponse(exec_ansible_apt_updater())

def which_ansible_playbook(request):
    return StreamingHttpResponse(exec_which_ansible_playbook())

from django.views.decorators.http import condition

# @condition(etag_func=None)
# def run_ansible_playbook(request):
#     resp = HttpResponse( exec_ansible_playbook_runner(), mimetype='text/html')
#     return resp

# def run_ansible_playbook(request):
#     return StreamingHttpResponse(exec_ansible_playbook_runner())

def gen_message(msg):
    return 'data: {}'.format(msg)


def iterator():
    for i in range(10000):
        yield gen_message('iteration ' + str(i))


def test_stream(request):
    #stream = run_ansible_playbook()
    response = StreamingHttpResponse(exec_ansible_playbook_runner())
    #response = StreamingHttpResponse(stream, status=200, content_type='text/event-stream')
    response['Cache-Control'] = 'no-cache'
    return response


def run_ansible_playbook(request):
    response= StreamingHttpResponse(exec_ansible_playbook_runner())
    response['Cache-Control'] = 'no-cache'
    return response
    #return render(request, 'home/run-ansible-playbook.html')


def ansible_test(request):
    # html_template=loader.get_template()
    # result = exec_ansible_apt_updater()
    return render(request, 'home/ansible.html')

def Starter(request):
    # html_template=loader.get_template()
    # result = exec_ansible_apt_updater()
    return render(request, 'home/starter.html')


# class PlaybookDetailView(ListView, FormView):
#     template_name = 'home/playbooks.html'

#     model = Playbook

#     form_class = PlaybookForm
#     success_url = '/playbooks/'

#     def form_valid(self, form):
#         form.save()
#         return super(PlaybookDetailView, self).form_valid(form)

#     def get_context_data(self, **kwargs):
#         context = super(PlaybookDetailView, self).get_context_data(**kwargs)
#         context['playbook'] = Playbook.objects.all()
#         return context

# class PlaybookReadView(BSModalReadView):

#     template_name = 'home/read-playbook.html'
#     model = Playbook
    
#     print(filename)
#     with open ('/Users/tkmahabage/projectV0/projectV0_v1.1/project-exn-1.0/core/media'+filename,'w+') as fl:
#         filebody = fl.read()
#     fl.close()
#     print(filebody)
    # return render(request,'home/read-playbook.html',{'filebody': filebody})  
    # return render(request,"home/read-playbook.html",context)


def readplaybook(request):
    template_name = 'home/readplaybook.html'
    if request.method == 'GET':
        print("GET")
        playbookfilename= request.POST["playbookfilename"]
        print(playbookfilename)
        context = {}
        filename = "/Users/tkmahabage/projectV0/projectV0_v1.1/project-exn-1.0/core/media"+"/"+playbookfilename
        print(filename)
        f = open(filename, 'r')
        filebody = f.read()
        
        f.close()
        print(filebody)
        context = {'filebody': filebody}
    return render(request, "home/readplaybook.html", context)

# def playbook_content(request, playbook_id):
#     template_name = 'home/playbook-content.html'
#     if request.method == 'POST':
#         filename = get_object_or_404(Playbook, pk=playbook_id)
#         with open(filename,'r') as file:
#             #list to return
#             file_content = file.read()
#         file.close
#         context = { "file_content" : file_content}
#     return render(request,"home/playbooks.html",context)
# def read_file(request):
#         if request.method == 'POST':
#             with open (request.POST['ViewButton']) as fl:
#                 file_content = fl.read()
#             fl.close
#             context = {'file_content': file_content}
#         return render(request,"home/read-playbook.html",context)



class PlaybookDeleteView(BSModalDeleteView):
    model = Playbook
    template_name = 'home/delete-playbook.html'
    success_message = 'Success: Playbook was deleted.'
    success_url = reverse_lazy('Playbooks')


class VulnerabilityReadView(BSModalReadView):
    template_name = 'home/read-vulnerability.html'
    model = Vulnerability
    

class VulnerabilityReport(SingleTableMixin, FilterView):
    table_class = VulnerabilityTable
    model = Vulnerability
    template_name = 'home/getvulnerabilities.html'
    
    filterset_class = VulnerabilityFilter
    paginate_by = 100

class HostReport(SingleTableMixin, FilterView):
    table_class = HostTable
    model = Host
    template_name = 'home/gethosts.html'
    
    filterset_class = HostFilter
    paginate_by = 100


from urllib.request import urlopen
from bs4 import BeautifulSoup


def get_news_feed(request):
    response= StreamingHttpResponse(exec_ansible_playbook_runner())
    response['Cache-Control'] = 'no-cache'
    return response


def newsfeed(request):
    
#     if request.method == 'GET':
# # def news(xml_news_url):
    NEWS_URL = "https://msrc-blog.microsoft.com/feed/"
    f= open("news.txt","w+")
    parse_xml_url = urlopen(NEWS_URL)
    xml_page = parse_xml_url.read()
    parse_xml_url.close()

    soup_page = BeautifulSoup(xml_page, "xml")
    news_list = soup_page.findAll("item")
    output = news_list
    for getfeed in news_list:

        f.write("\n<html>")
        f.write('\033[1;33m %s \033[1;m' %getfeed.title.text)
        f.write('\033[1;32m %s \033[1;m' %getfeed.link.text)
        f.write('\033[1;35m %s \033[1;m' %getfeed.pubDate.text)
        f.write("\n")
    filebody = f.read()
    f.close()
    print(filebody)
    context = {'output': output}
    #NEWS_URL = "https://www.oracle.com/ocom/groups/public/@otn/documents/webcontent/rss-otn-sec.xml"
    return render(request, "home/newsfeed.html", context)
    

# def newsfeed(request):
#     context = {'playbooks' : Playbook.objects.all().order_by('id')}
#     return render(request, 'manager/index.html', context)

############ HostVulnerability #############
class HostVulnerabilityList(ListView):
    model = HostVulnerability	
	
class HostVulnerabilityView(DetailView):
    model = HostVulnerability

class HostVulnerabilityCreate(CreateView):
    model = HostVulnerability
    fields = [ 'host','vulnerability','comment', 'status']
    success_url = reverse_lazy('vulnerabilitys')

class HostVulnerabilityUpdate(UpdateView):
    model = HostVulnerability
    fields = [ 'host','vulnerability','comment', 'status']
    success_url = reverse_lazy('vulnerabilitys')

class HostVulnerabilityDelete(DeleteView):
    model = HostVulnerability
    success_url = reverse_lazy('vulnerabilitys')


# from templates.home.signals import new_hostvulnerability

def hostvulnerability(request, id):
    vulnerability = Vulnerability.objects.get(pk=id)
    host = Host.objects.get(pk=id)
    hostvulnerability.save()
    


def hostvulnerabilitystatusupdate(request, pk):
    hostvulnerability = get_object_or_404(HostVulnerability, pk=pk)
    #object = HostVulnerability.objects.get(id=id)
    hostvulnerability(hostvulnerability)
    if request.method == 'POST':
        form = HostVulnerabilityModelForm(instance=hostvulnerability)
        if form.is_valid():
            form.save()
            return redirect('vulnerabilitys')
    else:
        form = HostVulnerabilityModelForm(instance=hostvulnerability)
    
    return render(request, '/home/hostvulnerabilitystatusupdate.html', {'form':form})