from django_filters import FilterSet
from django_filters import rest_framework as filters
import django_filters
from django_filters import FilterSet
from .models import Playbook, Inventory, Vulnerability, Host


class PlaybookFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr='icontains')
    class Meta:
        model = Playbook
        fields = ['id']

class InventoryFilter(django_filters.FilterSet):
    name = django_filters.CharFilter(lookup_expr='icontains')
    class Meta:
        model = Inventory
        fields = ['name']

class VulnerabilityFilter(django_filters.FilterSet):
    IP = django_filters.CharFilter(lookup_expr='icontains',  label='IP')
    OS = django_filters.CharFilter(lookup_expr='icontains',  label='OS')
    QID = django_filters.CharFilter(lookup_expr='icontains',  label='QID')
    Title = django_filters.CharFilter(lookup_expr='icontains',  label='Title')
    Type = django_filters.CharFilter(lookup_expr='icontains',  label='Type')
    Severity = django_filters.CharFilter(lookup_expr='icontains',  label='Severity')
    VulnStatus = django_filters.CharFilter(lookup_expr='icontains',  label='Status')
#    Port = django_filters.CharFilter(lookup_expr='icontains')

    class Meta:
        model = Vulnerability
        fields = ['IP','OS', 'QID', 'Title','Type','Severity', 'Port']

class HostFilter(django_filters.FilterSet):
    DNS = django_filters.CharFilter(lookup_expr='icontains',  label='DNS')
    IP = django_filters.CharFilter(lookup_expr='icontains',  label='IP')
    operatingsystem = django_filters.CharFilter(lookup_expr='icontains',  label='OS')
    owner = django_filters.CharFilter(lookup_expr='icontains',  label='Owner')
    Servertype = django_filters.CharFilter(lookup_expr='icontains',  label='Server Type')
    
    class Meta:
        model = Host
        fields = ['DNS','IP', 'operatingsystem', 'owner','Servertype']