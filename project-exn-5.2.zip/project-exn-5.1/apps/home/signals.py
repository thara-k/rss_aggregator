from django.db.models import signals
from django.dispatch import receiver, Signal
from .models import HostVulnerability, Vulnerability
import django.dispatch
# # pre_save method signal
# @receiver(signals.pre_save, sender=HostVulnerability)
# def check_product_description(sender, instance, **kwargs):
#     if not instance.description:
#         instance.description = 'This is Default Description'
    
# post_save method
@receiver(signals.post_save, sender=HostVulnerability) 
def new_hostvulnerability(sender, instance, created, **kwargs):
    print("Save method is called") 

@receiver(signals.post_save, sender=Vulnerability) 
def new_tvulnerability(sender, instance, created, **kwargs):
    print("Save method is called") 


vulnerability_viewed = django.dispatch.Signal(providing_args=["vulnerabilitys","user"])