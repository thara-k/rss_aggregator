from import_export import resources
from .models import Vulnerability


class VulnerabilityResource(resources.ModelResource):
    class Meta:
        model = Vulnerability
        fields=('IP', 'DNS', 'NetBIOS', 'TrackingMethod', 'OS', 'IPStatus', 'QID',   'Title', 'VulnStatus', 'Type', 'Severity', 'Port', 'Protocol',   'FirstDetected', 'LastDetected', 'TimesDetected', 'DateLastFixed',   'FirstReopened', 'LastReopened', 'TimesReopened', 'CVEID',   'VendorReference', 'BugtraqID', 'Threat', 'Impact', 'Solution',   'Exploitability', 'Results', 'PCIVuln', 'TicketState', 'Category')