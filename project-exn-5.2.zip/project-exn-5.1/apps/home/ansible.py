import os
import subprocess
import time
import sys
# import ansible
os.environ['SYSTEMD_COLORS'] = '1'

# import colorama


def exec_ansible_apt_updater():
    root_dir = "/Users/tkmahabage/projectV0/playbooks"
    # os.chdir(root_dir)
    # print("hello")
    # # output = subprocess.run(['apt_updater.sh'], shell=True)
    # output = subprocess.run(['cmd', '/c', 'dir'], cwd="C:/Windows/System32")
    # colorama.init(autoreset=True)
    with subprocess.Popen(['sh','/Users/tkmahabage/projectV0/projectV0_v1.1/project-exn-1.0/check_health.sh'], stdout=subprocess.PIPE, bufsize=1,
                          universal_newlines=True) as p:
        "<h1>ansibe run</h1>"
        for line in p.stdout:
            time.sleep(0.2)
            print(line, end='')  # process line here
            # print(colorama.Fore.GREEN + p.stdout.decode())
            # yield f'{line}<br/>'
            yield f'{line}<br/>'
        if p.returncode != 0:
            raise subprocess.CalledProcessError(p.returncode, p.args)

    #
    # with subprocess.Popen(['cmd', '/c', 'dir'], cwd="C:/Windows/System32", stdout=subprocess.PIPE, bufsize=1,
    #                       universal_newlines=True) as p:
    #     for line in p.stdout:
    #         time.sleep(0.2)
    #         print(line, end='')  # process line here
    #         yield f'{line}<br>'
    # if p.returncode != 0:
    #     raise subprocess.CalledProcessError(p.returncode, p.args)

# /Users/tkmahabage/projectV0/playbooks/poc/check_services.sh
# return output

# os.chdir(root_dir + "/QIDmapper")
# LOGGER.info("Apt update Ansible Playbook executed!")
# for line in iter(output.stdout.readline, ''):
#     time.sleep(5)
#     yield f'{line}<br>'
def exec_ansible_playbook_runner():
    root_dir = "/Users/tkmahabage/projectV0/playbooks"
    logfile = open('logfile', 'w')

    # os.chdir(root_dir)
    # print("hello")
    # # output = subprocess.run(['apt_updater.sh'], shell=True)
    # output = subprocess.run(['cmd', '/c', 'dir'], cwd="C:/Windows/System32")
    # colorama.init(autoreset=True)which_playbook.sh
    with subprocess.Popen(['sh','/Users/tkmahabage/projectV0/projectV0_v1.1/project-exn-1.0/ping_host.sh'], stdout=subprocess.PIPE, bufsize=1,
                          universal_newlines=True) as p:
        "<h1>ansibe run</h1>"
        for line in p.stdout:
            sys.stdout.write(line)
            logfile.write(line)
            
            #time.sleep(0.2)
            print(line, end='')  # process line here
            # print(colorama.Fore.GREEN + p.stdout.decode())
            # yield f'{line}<br/>'
            yield f'{line}<br/>'
        if p.returncode != 0:
            raise subprocess.CalledProcessError(p.returncode, p.args)

def exec_which_ansible_playbook():
    root_dir = "/Users/tkmahabage/projectV0/playbooks"
    logfile = open('logfile', 'w')

    # os.chdir(root_dir)
    # print("hello")
    # # output = subprocess.run(['apt_updater.sh'], shell=True)
    # output = subprocess.run(['cmd', '/c', 'dir'], cwd="C:/Windows/System32")
    # colorama.init(autoreset=True)which_playbook.sh
    # with subprocess.Popen(['sh','/Users/tkmahabage/projectV0/projectV0_v1.1/project-exn-1.0/which_playbook.sh'], stdout=subprocess.PIPE, bufsize=1,
    with subprocess.Popen(['sh','/Users/tkmahabage/projectV0/projectV0_v1.1/project-exn-1.0/ansible.sh'], stdout=subprocess.PIPE, bufsize=1,
                          universal_newlines=True) as p:
        "<h1>ansibe run</h1>"
        for line in p.stdout:
            sys.stdout.write(line)
            logfile.write(line)
            
            #time.sleep(0.2)
            print(line, end='')  # process line here
            # print(colorama.Fore.GREEN + p.stdout.decode())
            # yield f'{line}<br/>'
            yield f'{line}<br/>'
        if p.returncode != 0:
            raise subprocess.CalledProcessError(p.returncode, p.args)

def example():
    for i in range(5):
        # Add <br> to break line in browser
        yield f'{i}<br>'
        time.sleep(0.5)


if __name__ == "__main__":
    exec_ansible_apt_updater()
