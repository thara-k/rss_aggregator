from .models import Playbook
from rest_framework import serializers

class PlaybookSerializer(serializers.ModelSerializer):
    class Meta:
        model = Playbook
        fields = '__all__'