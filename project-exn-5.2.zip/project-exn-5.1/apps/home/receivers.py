from ..templates.home.signals import vulnerability_viewed
    
# post_save method
@receiver(signals.post_save, sender=HostVulnerability) 
def update_hostvulnerability(sender, instance, **kwargs):
    print("Save method is called") 

