# -*- encoding: utf-8 -*-
"""
Copyright (c) 2019 - present AppSeed.us
"""

from django.contrib import admin
from .models import Inventory, Host, Group, Playbook, Vulnerability,HostVulnerability,Solution

# Register your models here.
class InventoryAdmin(admin.ModelAdmin):
    list_display = ['name','filepath']

class HostAdmin(admin.ModelAdmin):
    list_display = ['IP']

class GroupAdmin(admin.ModelAdmin):
    list_display = ['name']

class PlaybookAdmin(admin.ModelAdmin):
    list_display = ['id']

class VulnerabilityAdmin(admin.ModelAdmin):
    list_display = ['id']

class HostVulnerabilityAdmin(admin.ModelAdmin):
    list_display = ['id']

class SolutionAdmin(admin.ModelAdmin):
    list_display = ['id']

admin.site.register(Inventory, InventoryAdmin)
admin.site.register(Host, HostAdmin)
admin.site.register(Group, GroupAdmin)
admin.site.register(Playbook, PlaybookAdmin)
admin.site.register(Vulnerability, VulnerabilityAdmin)
admin.site.register(HostVulnerability, HostVulnerabilityAdmin)
admin.site.register(Solution, SolutionAdmin)
