import os
import subprocess
import time


def exec_ansible_apt_updater():
    root_dir = "C:/Projects/python/django/vfixer/apps/home/"
    # os.chdir(root_dir)
    # print("hello")
    # # output = subprocess.run(['apt_updater.sh'], shell=True)
    # output = subprocess.run(['cmd', '/c', 'dir'], cwd="C:/Windows/System32")
    with subprocess.Popen(['cmd', '/c', 'dir'], stdout=subprocess.PIPE, bufsize=1,
                          universal_newlines=True) as p:
        "<h1>ansibe run</h1>"
        for line in p.stdout:
            time.sleep(0.2)
            print(line, end='')  # process line here
            # yield f'{line}<br/>'
            yield f'{line}<br/>'
        if p.returncode != 0:
            raise subprocess.CalledProcessError(p.returncode, p.args)

    #
    # with subprocess.Popen(['cmd', '/c', 'dir'], cwd="C:/Windows/System32", stdout=subprocess.PIPE, bufsize=1,
    #                       universal_newlines=True) as p:
    #     for line in p.stdout:
    #         time.sleep(0.2)
    #         print(line, end='')  # process line here
    #         yield f'{line}<br>'
    # if p.returncode != 0:
    #     raise subprocess.CalledProcessError(p.returncode, p.args)


# return output

# os.chdir(root_dir + "/QIDmapper")
# LOGGER.info("Apt update Ansible Playbook executed!")
# for line in iter(output.stdout.readline, ''):
#     time.sleep(5)
#     yield f'{line}<br>'


def example():
    for i in range(5):
        # Add <br> to break line in browser
        yield f'{i}<br>'
        time.sleep(0.5)


if __name__ == "__main__":
    exec_ansible_apt_updater()
