#!/bin/bash
#export SYSTEMD_COLORS=1 
#echo ""
#echo ""
#echo " Connecting..."
#echo " Please wait"
#ansible s89   -i ./hosts -m ping
#echo ""
#echo ""
#echo "Done"

ping 10.64.167.89 -c 10
